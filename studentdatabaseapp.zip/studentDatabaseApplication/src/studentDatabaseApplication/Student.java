package studentDatabaseApplication;

import java.util.Scanner;

public class Student {
	/*
	 * Ask users how many students will be added to the database The user should be
	 * prompted to enter the name and year for each student the student should have
	 * 5-digit unique-id,with the first number being their grade level the student
	 * can enroll in the following courses: History101,Mathematics 101,English
	 * 101,Chemistry 101,Computer Science 101 Each course cost 600 The student
	 * should be able to view their balance and pay the tution fees To see the
	 * status of the resident we should see their name,Id,course enrolled and
	 * balance.
	 */
	private String firstname;
	private String lastname;
	private int gradeyear;
	private String studentID;
	private String courses = null;
	private int tutionbalance = 0;
	private static int costofcourse = 600;
	private static int id = 1000;

	public Student() {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the student first name: ");
		this.firstname = in.nextLine();
		System.out.print("Enter the student last name: ");
		this.lastname = in.nextLine();
		System.out.print("1-Freshman\n2- sophomore\n3 - junior\n4 - senior\nEnter Student class level: ");
		this.gradeyear = in.nextInt();
		setstudentID();
		// System.out.println(firstname + " " + lastname + " " + " " + gradeyear + " " +
		// studentID);

	}

	private void setstudentID() {
		id++;
		this.studentID = gradeyear + "" + id;

	}

	public void enroll() {
		do {
			System.out.print("Enter a course to enroll(Q to quit): ");
		Scanner in = new Scanner(System.in);
		String course = in.nextLine();
		if (!course.equals("Q")) {
			courses = courses + "\n" + course;
			tutionbalance = tutionbalance + costofcourse;
		}
		else {break;}
	} while (1 != 0);
	// System.out.println("ENROLLED IN: " + courses);
	// tgtSystem.out.println("TUTION BALANCE: " + tutionbalance);
	}

	public void viewBalance() {
		System.out.println("Your balance is: $ " + tutionbalance);
	}

	public void payTution() {
		viewBalance();
		System.out.println("Enter your payment: $");
		Scanner in = new Scanner(System.in);
		int payment = in.nextInt();
		tutionbalance = tutionbalance - payment;
		System.out.println("Thank you for your payment of $" + payment);
		viewBalance();
	}

	@Override
	public String toString() {
		return "Name: " + firstname + " " + lastname + "\nGrade level: " + gradeyear + "\nStudent ID: " + studentID
				+ "\nCourses Enrolled: " + courses + "\nBalance: $ " + tutionbalance;

	}

}
